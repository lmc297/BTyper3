class FinalResults:
	"""
	Print final results file
	"""

	def __init__(self, final_results_directory, infile, prefix, species, subspecies, anthracis, emetic, bt_final):

		self.final_results_directory = final_results_directory
		self.infile = infile,
		self.prefix = prefix
		self.species = species
		self.subspecies = subspecies
		self.anthracis = anthracis
		self.emetic = emetic
		self.bt_final = bt_final

	def print_final_results(self, final_results_directory, infile, prefix, species, subspecies, anthracis, emetic, bt_final):

		header = ["#filename", "prefix", "species(ANI)", "subspecies(ANI)", "cereulide(genes)", "anthrax_toxin(genes)", "Bt(genes)", "final_taxon_names"]

		biovars = []
		Anthracis = str(len(anthracis)) + "/3(" + ";".join(anthracis) + ")"
		Emeticus = str(len(emetic)) + "/4(" + ";".join(emetic) + ")"
		Thuringiensis = str(len(bt_final)) + "(" + ";".join(bt_final) + ")"
		if len(anthracis) >= 2:
			if len(anthracis) == 3:
				biovars.append("Anthracis")
			else:
				biovars.append("Anthracis*")
		if len(emetic) >= 2:
			if len(emetic) == 4:
				biovars.append("Emeticus")
			else:
				biovars.append("Emeticus*")
		if len(bt_final) >= 1:
			biovars.append("Thuringiensis")

		final_taxon = ""
		final_species = species.split("(")[0].strip()	
		final_subspecies = subspecies.split("(")[0].strip()
		final_biovars = ",".join(biovars)
		if final_subspecies == "anthracis":
			final_taxon = "B. mosaicus subsp. anthracis"
		elif final_subspecies == "cereus":
			final_taxon = "B. mosaicus subsp. cereus"
		else:
			if "*" not in final_species and len(final_species) > 0:
				final_taxon = "B. " + final_species
			else:
				final_taxon = "(Species unknown)"
		if len(biovars) > 0:
			if len(biovars) == 1:
				final_taxon = final_taxon + " biovar "
			else:
				final_taxon = final_taxon + " biovars "
			final_taxon = final_taxon + final_biovars
		if final_subspecies == "anthracis" or final_subspecies == "cereus":
			if final_subspecies == "anthracis":
				final_taxon = final_taxon + "; B. anthracis"
			elif final_subspecies == "cereus":
				final_taxon = final_taxon + "; B. cereus"
			if len(biovars) > 0:
				if len(biovars) == 1:
					final_taxon = final_taxon + " biovar "
				else:
					final_taxon = final_taxon + " biovars "
				final_taxon = final_taxon + final_biovars
		if len(biovars) > 0:
			final_taxon = final_taxon + "; B. " + final_biovars
			

		final_line = [infile, prefix, species, subspecies, Anthracis, Emeticus, Thuringiensis, final_taxon]

		with open(final_results_directory + prefix + "_final_results.txt", "a") as outfile:
			print("\t".join(header), file = outfile)
			print("\t".join(final_line), file = outfile)
